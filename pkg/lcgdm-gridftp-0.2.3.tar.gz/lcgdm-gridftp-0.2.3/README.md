## puppet-gridftp module
[![Puppet Forge](http://img.shields.io/puppetforge/v/lcgdm/gridftp.svg)](https://forge.puppetlabs.com/lcgdm/gridftp)
[![Build Status](https://travis-ci.org/cern-it-sdc-id/puppet-gridftp.svg?branch=master)]([https://travis-ci.org/cern-it-sdc-id/puppet-gridftp.svg)

This is the puppet-gridftp module, it configures a Globus gridftp server, developed at CERN , IT-SDC-ID section

### License
ASL 2.0

### Contact
Andrea Manzi <andrea.manzi@cern.ch>

## Support
Tickets and issues at our [cern-it-sdc-id site](https://github.com/cern-it-sdc-id)
